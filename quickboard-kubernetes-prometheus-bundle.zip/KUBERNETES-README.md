# Kubernetes 部署與回滾

## 前置元件
- Kubernetes 叢集與預設 StorageClass
- Ingress NGINX 或自行調整 ingressClassName
- cert-manager 與 `letsencrypt-prod` ClusterIssuer
- 選用：kube-prometheus-stack，提供 Prometheus Operator、Grafana、Alertmanager、kube-state-metrics

## 準備
```bash
cp k8s/01-config-secret.example.yaml k8s/01-config-secret.yaml
# 編輯 Secret、網域、image 與 StorageClass
kubectl config current-context
```
不要將 `01-config-secret.yaml` 提交 Git。

## 部署
```bash
./scripts/k8s-deploy.sh ghcr.io/YOUR_ORG/quickboard:1.2.3
./scripts/k8s-verify.sh
```
部署腳本會做 server-side dry run、套用資源、設定映像、等待 rollout，失敗時執行 `rollout undo`。

## 回滾
```bash
kubectl -n quickboard rollout history deployment/quickboard
./scripts/k8s-rollback.sh
# 或指定 revision
./scripts/k8s-rollback.sh 3
```
Kubernetes Deployment 可保留與回復之前的 ReplicaSet revision；本專案設定 `revisionHistoryLimit: 5`。SQLite 資料庫不會因 Deployment 回滾而自動回復，若資料格式不相容，必須另行使用經驗證的備份還原程序。

## 監控
如已安裝 kube-prometheus-stack：
```bash
kubectl apply -f k8s/06-monitoring.yaml
kubectl -n monitoring get servicemonitor,prometheusrule
```
匯入 `monitoring/grafana/quickboard-dashboard.json` 至 Grafana。

## SQLite 限制
本版使用 SQLite 與 ReadWriteOnce PVC，因此維持 1 個 Pod，並採 Recreate 策略。若需要零停機、多副本或跨節點高可用，請先將資料庫遷移至 PostgreSQL，再改用 RollingUpdate 與 replicas > 1。
