#!/bin/sh
set -eu
revision="${1:-}"; ns=quickboard
kubectl -n "$ns" rollout history deployment/quickboard
if [ -n "$revision" ]; then kubectl -n "$ns" rollout undo deployment/quickboard --to-revision="$revision"; else kubectl -n "$ns" rollout undo deployment/quickboard; fi
kubectl -n "$ns" rollout status deployment/quickboard --timeout=180s
kubectl -n "$ns" get pods -l app=quickboard -o wide
