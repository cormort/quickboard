#!/bin/sh
set -eu
image="${1:-}"; [ -n "$image" ] || { echo "Usage: $0 IMAGE[:TAG]" >&2; exit 2; }
ns=quickboard
kubectl apply --dry-run=server -f k8s/00-namespace.yaml
kubectl apply -f k8s/00-namespace.yaml
kubectl apply --dry-run=server -f k8s/01-config-secret.yaml -f k8s/02-pvc.yaml -f k8s/03-deployment-service.yaml -f k8s/04-ingress.yaml -f k8s/05-backup-cronjob.yaml
kubectl apply -f k8s/01-config-secret.yaml -f k8s/02-pvc.yaml -f k8s/03-deployment-service.yaml -f k8s/04-ingress.yaml -f k8s/05-backup-cronjob.yaml
kubectl -n "$ns" set image deployment/quickboard quickboard="$image" --record=false
kubectl -n "$ns" rollout status deployment/quickboard --timeout=180s || { kubectl -n "$ns" rollout undo deployment/quickboard; kubectl -n "$ns" rollout status deployment/quickboard --timeout=180s; exit 1; }
kubectl apply -f k8s/06-monitoring.yaml -f k8s/07-networkpolicy-pdb.yaml
kubectl -n "$ns" get pods,svc,ingress,pvc
