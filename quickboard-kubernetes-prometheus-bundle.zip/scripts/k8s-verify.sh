#!/bin/sh
set -eu
ns=quickboard
kubectl auth can-i get pods -n "$ns"
kubectl -n "$ns" get deploy quickboard -o jsonpath='{.status.availableReplicas}' | grep -Eq '^[1-9]'
kubectl -n "$ns" wait --for=condition=ready pod -l app=quickboard --timeout=120s
kubectl -n "$ns" get pvc quickboard-data -o jsonpath='{.status.phase}' | grep -qx Bound
kubectl -n "$ns" run qb-check --rm -i --restart=Never --image=curlimages/curl:8.10.1 -- curl -fsS http://quickboard/api/health
kubectl -n "$ns" run qb-metrics --rm -i --restart=Never --image=curlimages/curl:8.10.1 -- sh -c 'curl -fsS http://quickboard/metrics | grep quickboard_http_requests_total'
echo 'Kubernetes verification passed.'
