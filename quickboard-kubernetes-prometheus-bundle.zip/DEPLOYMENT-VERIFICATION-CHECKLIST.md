# 部署前後驗證清單

## 部署前
- [ ] 映像使用不可變版本或 digest，未使用 `latest`。
- [ ] 映像已完成弱點掃描與 SBOM 保存。
- [ ] `kubectl config current-context` 指向正確叢集。
- [ ] `kubectl auth can-i` 確認部署帳號權限符合最小權限。
- [ ] Namespace、StorageClass、IngressClass、cert-manager issuer 存在。
- [ ] `01-config-secret.example.yaml` 已複製成 `01-config-secret.yaml` 並換掉所有秘密。
- [ ] APP_SECRET、管理員密碼、Webhook／SMTP 密碼未提交 Git。
- [ ] PVC 容量與備份 PVC 容量足夠。
- [ ] 已建立可還原的 SQLite 備份並完成 `PRAGMA integrity_check`。
- [ ] `kubectl apply --dry-run=server` 與 YAML lint 通過。
- [ ] `/api/health`、`/metrics` 已在測試環境驗證。
- [ ] Prometheus Operator CRD 已存在，再套用 ServiceMonitor 與 PrometheusRule。
- [ ] 已確認 SQLite 僅能使用 1 個寫入 Pod，本版 Deployment 固定 replicas=1、strategy=Recreate。
- [ ] 已記錄目前 Deployment revision 與 image digest。

## 部署中
- [ ] `kubectl rollout status` 在 180 秒內成功。
- [ ] startup、readiness、liveness probe 均成功。
- [ ] Pod 無 CrashLoopBackOff、OOMKilled、ImagePullBackOff。
- [ ] PVC 為 Bound，Pod 可讀寫 `/data`。
- [ ] Ingress TLS 憑證 Ready，主機名稱正確。
- [ ] NetworkPolicy 套用後，Ingress 與 Prometheus 仍可存取服務。

## 部署後自動驗證
```bash
./scripts/k8s-verify.sh
```
- [ ] 叢集內 `/api/health` 回傳成功。
- [ ] `/metrics` 包含 `quickboard_http_requests_total`。
- [ ] ServiceMonitor targets 為 UP。
- [ ] PrometheusRule 已載入且無語法錯誤。
- [ ] Grafana 面板可看到狀態、請求率、延遲、5xx 與資料總量。
- [ ] 登入、邀請註冊、發文、複製、離線待送、後台及審計查詢完成人工煙霧測試。
- [ ] CronJob 可手動建立 Job 並產生可還原備份。
- [ ] 告警測試通知可到達預期管道。

## 回滾判定
下列任一情況應停止部署並回滾：
- readiness 在時限內未通過。
- 5xx 比率持續超過 5%。
- P95 延遲持續超過 1 秒。
- 登入或資料庫讀寫失敗。
- 審計、備份或資料遷移出現不可接受錯誤。
