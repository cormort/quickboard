# FastAPI 指標整合

1. `requirements.txt` 加入 `prometheus-client==0.21.1`。
2. 將 `metrics.py` 放進 `app/metrics.py`。
3. 在 `app/main.py` 匯入 `time`、SQLAlchemy `func`，以及 `app.metrics`。
4. 加入 HTTP middleware，使用路由模板而不是原始 URL，避免高基數標籤。
5. 加入 `/metrics`，更新 users、rooms、messages gauges 後回傳 `metrics_response()`。

```python
import time
from . import metrics as qm

@app.middleware("http")
async def prometheus_middleware(request, call_next):
    started = time.perf_counter()
    response = await call_next(request)
    route = request.scope.get("route")
    path = getattr(route, "path", request.url.path)
    qm.HTTP_REQUESTS.labels(request.method, path, str(response.status_code)).inc()
    qm.HTTP_LATENCY.labels(request.method, path).observe(time.perf_counter() - started)
    return response

@app.get("/metrics", include_in_schema=False)
def prometheus_metrics(db: Session = Depends(db_session)):
    qm.USERS.set(db.scalar(select(func.count()).select_from(User)) or 0)
    qm.ROOMS.set(db.scalar(select(func.count()).select_from(Room)) or 0)
    qm.MESSAGES.set(db.scalar(select(func.count()).select_from(Message)) or 0)
    return qm.metrics_response()
```
