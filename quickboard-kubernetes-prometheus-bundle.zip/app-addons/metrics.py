from prometheus_client import Counter, Histogram, Gauge, generate_latest, CONTENT_TYPE_LATEST
from fastapi import Response
HTTP_REQUESTS=Counter('quickboard_http_requests_total','HTTP requests',['method','path','status'])
HTTP_LATENCY=Histogram('quickboard_http_request_duration_seconds','HTTP latency',['method','path'])
BACKUP_SUCCESS=Gauge('quickboard_backup_last_success_timestamp','Last successful backup unix timestamp')
BACKUP_STATUS=Gauge('quickboard_backup_status','Last backup status, 1 success 0 failure')
MESSAGES=Gauge('quickboard_messages_total','Stored messages')
ROOMS=Gauge('quickboard_rooms_total','Rooms')
USERS=Gauge('quickboard_users_total','Users')
def metrics_response(): return Response(generate_latest(),media_type=CONTENT_TYPE_LATEST)
